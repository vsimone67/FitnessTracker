import { Component } from '@angular/core';

@Component({
  selector: 'fitnesstracker',
  templateUrl: './app.component.html'
})
export class AppComponent {
}
