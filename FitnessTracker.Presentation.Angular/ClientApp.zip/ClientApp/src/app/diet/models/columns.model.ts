export class Columns {
  MealId: number;
  MealName: string;
  MealDisplayName: string;
}
