export class CurrentMacros {
  calories: number;
  caloriesFactor: number;
  protein: number;
  proteinFactor: number;
  carbs: number;
  carbsFactor: number;
  fat: number;
  fatFactor: number;
  weight: number;
  weightFactor: number;
  dcr: number;
  dcrFactor: number;
}
