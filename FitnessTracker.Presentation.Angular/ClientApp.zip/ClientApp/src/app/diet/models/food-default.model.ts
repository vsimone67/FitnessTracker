export class FoodDefault {
  DefaultServing: string;
  Meal: string;
  DefaultId: number;
  ItemId: number;
  MealId: number;
}
