export const MeatabolicInfoConstants = {
  dcr: 'DCR',
  bmr: 'BMR',
  actlvl: 'ACTLVL',
  caldefper: 'CALDEFPER',
  proteinper: 'PROTEINPER',
  carbsper: 'CARBSPER',
  fatper: 'FATPER',
  calories: 'CALORIES',
  weight: 'WEIGHT'
}
