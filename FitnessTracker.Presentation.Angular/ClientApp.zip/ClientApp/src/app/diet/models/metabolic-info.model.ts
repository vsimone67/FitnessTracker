export class MeatabolicInfo {
  MetabolicInfoId: number;
  macro: string;
  factor: number;
  cut: number;
  maintain: number;
  gain: number;
}
