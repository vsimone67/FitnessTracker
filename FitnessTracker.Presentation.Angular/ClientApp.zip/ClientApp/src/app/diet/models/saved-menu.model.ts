export class SavedMenu {
  public Id: number;
  public Serving: number;
  public ItemId: number;
  public MealId: number;
}
