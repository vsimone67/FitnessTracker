import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navagation',
  templateUrl: 'navagation.component.html'
})
export class NavagationComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
