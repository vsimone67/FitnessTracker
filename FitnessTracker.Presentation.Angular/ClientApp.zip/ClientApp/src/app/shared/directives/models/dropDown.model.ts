export class DropDownModel {
  displayName: string;
  value: any;

  constructor(name: string, value: any) {
    this.displayName = name;
    this.value = value;
  }
}
