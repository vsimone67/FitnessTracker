export const events = {
  toastEvent: 'toastEvent',
  spinnerEvent: 'spinnerEvent',
  addSetEvent: 'addSetEvent'
};
