export const SiteConstants = {
  apiServer: 'http://vsfitnesstrackerapi.azurewebsites.net/'
  // apiServer: 'http://vsfitnesstrackertest.azurewebsites.net/'
  //apiServer: 'http://localhost:62910/'
}
