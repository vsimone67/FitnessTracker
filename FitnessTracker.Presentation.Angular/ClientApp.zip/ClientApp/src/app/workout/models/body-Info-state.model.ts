import { BodyInfo } from ".";

export interface BodyInfoStateModel {
  bodyInfoItems: Array<BodyInfo>;
}
