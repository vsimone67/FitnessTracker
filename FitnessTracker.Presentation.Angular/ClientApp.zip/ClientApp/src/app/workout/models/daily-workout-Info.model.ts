export class DailyWorkoutInfo {
  public DailyWorkoutInfoId: number;
  public WeightUsed: number;
  public DailyWorkoutId: number;
  public WorkoutId: number;
  public ExerciseId: number;
  public SetId: number;
  public RepsId: number;
}
