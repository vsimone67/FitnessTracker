export class ExerciseName {
  ExerciseNameId: number;
  Name: string;

  constructor() {
    this.ExerciseNameId = 0;
  }
}
