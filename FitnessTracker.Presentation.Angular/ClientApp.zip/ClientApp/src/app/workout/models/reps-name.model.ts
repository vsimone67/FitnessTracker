export class RepsName {
  RepsNameId: number;
  Name: string;

  constructor() {
    this.RepsNameId = 0;
  }
}
