export class Reps {
  public RepsId: number;
  public Weight: number;
  public Name: string;
  public TimeToNextExercise: string;
  public RepsNameId: number;
}
