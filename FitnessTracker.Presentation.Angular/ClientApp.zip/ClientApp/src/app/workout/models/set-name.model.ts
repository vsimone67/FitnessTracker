export class SetName {
  SetNameId: number;
  Name: string;

  constructor() {
    this.SetNameId = 0;
  }
}
